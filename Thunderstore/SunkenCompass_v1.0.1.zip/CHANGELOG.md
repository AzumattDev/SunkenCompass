| `Version` | `Update Notes`                        |
|-----------|---------------------------------------|
| 1.0.1     | - Hide the compass if any UI is open. |
| 1.0.0     | - Initial Release                     |