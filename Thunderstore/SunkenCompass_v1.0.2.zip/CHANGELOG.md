| `Version` | `Update Notes`                        |
|-----------|---------------------------------------|
| 1.0.2     | - Update for Sunkenland v0.150        |
| 1.0.1     | - Hide the compass if any UI is open. |
| 1.0.0     | - Initial Release                     |